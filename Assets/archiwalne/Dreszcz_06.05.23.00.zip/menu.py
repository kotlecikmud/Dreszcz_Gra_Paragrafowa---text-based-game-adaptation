# - - - - - - - - -
# - - - - - - - - -
# - - - - - - - - -
# 'DRESZCZ'
# GRA PARAGRAFOWA
# autor: Jacek Ciesielski 1987
# oprogramowanie: Filip Pawłowski 2023
# /// wersja: 0.105
# - - - - - - - - -
# - - - - - - - - -
# - - - - - - - - -
import time, pygame, msvcrt
import functions, constants, paragraphs
from colorama import Fore

explainer = False #  przełącznik wyjaśnień w menu głównym

def main_menu():
    while True:
        functions.clear_terminal()
        print(f'{constants.def_txt_clr}MAIN MENU{constants.special_txt_clr}\
            \nWitaj {Fore.LIGHTYELLOW_EX}{constants.player_name}!{constants.def_txt_clr}')
        print(f"{constants.def_txt_clr}Wybierz parametr z listy:\
        \n")

        choices = [
            ('Graj', 'play the game'),
            ('Zasady Gry', 'read the rules'),
            ('Poziom trudności', 'set difficulty level'),
            ('Ustawienia Dźwięku', 'change sound levels'),
            ('Zmień imię bohatera', 'set player\'s name'),
            ('Wylosuj nowe parametry bohatera', 'randomize player stats'),
            ('komenda eval', 'only for testing purposes'),
            ('Wyjdź z gry', 'exit the game')
        ]

        template = "({}) {} - {}" if explainer else "({}) {}"

        for i, (choice, description) in enumerate(choices, 1):
            print(template.format(i, choice, description))

        odp = input(f'{constants.input_sign}{constants.special_txt_clr} ').strip()
        if odp.isdigit():
            index = int(odp) - 1
            if 0 <= index < len(choices):
                odp = choices[index][0]

        for choice, description in choices:
            if odp == choice:
                print(f"/// {choice}{constants.def_txt_clr}")
                functions.loading(1)

                if choice == 'Graj':
                    time.sleep(constants.delay)
                    pygame.mixer.music.fadeout(1800)
                    functions.clear_terminal()
                    paragraphs.par_00()

                elif choice == 'Zasady Gry':
                    time.sleep(constants.delay)
                    show_rules()

                elif choice == 'Poziom trudności':
                    time.sleep(constants.delay)
                    print(f'{constants.def_txt_clr}Wybierz poziom trudności:')
                    choices = ['łatwy', 'średni', 'trudny']
                    for i, path in enumerate(choices):
                        print(f'({i + 1}) - {path}')
                        time.sleep(constants.delay)

                    lvl_choice = functions.get_numeric_input(
                        f'\n{constants.input_sign} ',
                        min_value=1,
                        max_value=len(choices),
                        error_messages={
                            'not_numeric': f'/!/ {constants.special_txt_clr}Wybierz numer z listy.{constants.def_txt_clr}',
                            'too_small': f'/!/ {constants.special_txt_clr}Wybór nie może być ujemny.{constants.def_txt_clr}',
                            'too_large': f'/!/ {constants.special_txt_clr}Nie ma wyboru o numerze: {odp}{constants.def_txt_clr}',
                        }
                    )

                    e_mult_choices = {
                        1: constants.d_lvl_e,
                        2: constants.d_lvl_m,
                        3: constants.d_lvl_h,
                    }
                    constants.e_mult_choice = e_mult_choices[lvl_choice]

                elif choice == 'Zmień imię bohatera':
                    time.sleep(constants.delay)
                    print(f"Wybierz imię bohatera (wpisz 'los' aby wylosować imię) {constants.input_sign}")
                    constants.player_name = input(
                        f"{Fore.LIGHTYELLOW_EX}{constants.player_name} {constants.special_txt_clr}{constants.input_sign} ")
                    if constants.player_name == 'los':
                        functions.name_randomizer()

                elif choice == 'Wylosuj nowe parametry bohatera':
                    time.sleep(constants.delay)
                    print(f"Losowanie początkowych statystyk bohatera")
                    functions.loading(2)
                    functions.rpar()
                    functions.show_player_stats()
                    input(f'\r{constants.input_sign}')

                elif choice == 'komenda eval':
                    time.sleep(constants.delay)
                    paragraphs._xx()

                elif choice == 'Ustawienia Dźwięku':
                    time.sleep(constants.delay)
                    sound_settings()

                elif choice == 'Wyjdź z gry':
                    choice2 = input("Czy na pewno? [T/N]: ")
                    if choice2.upper() == "T":
                        time.sleep(constants.delay)
                        pygame.mixer.music.fadeout(2200)
                        functions.loading(2.2)
                        exit()
                    else:
                        main_menu()

    return constants.player_name, constants.e_mult_choice


def show_rules():
    functions.clear_terminal()

    choices = ['WYPOSAŻENIE I CECHY', 'WALKA', 'UCIECZKA', 'SZCZĘŚCIE',
               'PODWYŻSZANIE POZIOMU CECH', 'PROWIANT', 'CEL WYPRAWY', 'Wróć']
    actions = [rules_1_characteristics, rules_2_fighting, rules_3_escape, rules_4_luck,
               rules_5_increasing_character_levels, rules_6_provisions, rules_7_objective_of_the_expedition,
               return_to_main_menu]

    print(f'{constants.def_txt_clr}ZASADY GRY{constants.special_txt_clr}\
          \n{constants.def_txt_clr}Wybierz parametr z listy (1-{len(choices)}) {constants.input_sign}')

    while True:
        for i, choice in enumerate(choices):
            print(f'({i + 1}) {choice}')
        choice_num = input(f'{constants.input_sign}')

        try:
            choice_num = int(choice_num)
            if choice_num < 1 or choice_num > len(choices):
                raise ValueError
            break
        except ValueError:
            print(f'/!/ \'{choice_num}\' nie jest poprawnym numerem')


    actions[choice_num - 1]()  # Wywołanie funkcji odpowiadającej wybranej pozycji
    functions.clear_terminal()
    show_rules()


def rules_1_characteristics():
    print('I. WYPOSAŻENIE I CECHY\
        \n\
        \nJesteś Śmiałkiem.\
        \n\
        \nTwój ekwipunek to:')
    functions.show_equipment_list()
    print(f'Wędrując po podziemiach będziesz znajdował inne rodzaje broni i przedmioty.\
        \nPamiętaj, że - poza mieczem - każda broń może być wykorzystana tylko raz.\
        \nPodobnie, znajdowane przedmioty są jednorazowego użytku.\
        \nMożesz zabrać ze sobą jedną butelkę eliksiru.\
        \n\
        \nWybierasz spośród eliksirów: {constants.special_txt_clr}ZRĘCZNOŚCI{constants.def_txt_clr}, {constants.special_txt_clr}WYTRZYMAŁOŚCI{constants.def_txt_clr} i {constants.special_txt_clr}SZCZĘŚCIA{constants.def_txt_clr}.\
        \nMożna wypić go w dowolnym momencie, ale tylko dwukrotnie podczas przygody.\
        \n\
        \n{constants.def_txt_clr}Twoje cechy to: ZRĘCZNOŚĆ, WYTRZYMAŁOŚĆ i SZCZĘŚCIE.\
        \nPrzed zejściem do podziemi losowane są początkowe poziomy tych cech.\
        \nIch poziom będzie się nieustannie zmieniał podczas wędrówki,\
        \nale nie może przekroczyć poziomu początkowego.')
    input(constants.input_sign)


def rules_2_fighting():
    print('II. WALKA\
        \n\
        \nBędziesz walczył z potworami. Ich cechy (ZRĘCZNOŚĆ i WYTRZYMAŁOŚĆ) są indywidualne dla każdego wroga.\
        \nSystem walki jest automatycznym procesem. Do końca walki nie ma możliwości interackji,\
        \nchyba że tekst przewiduje możliwość ucieczki.')
    input(constants.input_sign)


def rules_3_escape():
    print('III. UCIECZKA\
        \n\
        \nBędąc w niebezpieczeństwie możesz ratować się Ucieczką, o ile tekst to przewiduje.\
        \nJeśli uciekasz, potwór zadaje ci ranę: odejmij 2 od swojej WYTRZYMAŁOŚCI.\
        \nPodczas Ucieczki (przed walką lub w jej trakcie) możesz zastosować SSS w opisany niżej sposób.')
    input(constants.input_sign)


def rules_4_luck():
    print('IV. SZCZĘŚCIE\
        \n\
        \nPodczas wędrówki sprawdzasz, czy szczęście ci sprzyja. Robisz to w następujący sposób:\
        \nRzucasz 2K. Jeśli wynik jest równy lub mniejszy od aktualnego poziomu SZCZĘŚCIA, to masz SZCZĘŚCIE.\
        \nJeśli wynik jest większy, nie masz SZCZĘŚCIA.\
        \nTa procedura nazywa się /Sprawdzanie Swojego Szczęścia (SSS).\
        \nPo każdym SSS - niezależnie od wyniku - należy odjąć 1 od aktualnego poziomu SZCZĘŚCIA.\
        \nSSS trzeba zrobić, gdy przewiduje to tekst, a także można zrobić podczas walki.\
        \nPodczas walki SSS robi się w odpowiednim momencie rundy (patrz wyżej), a jego wynik stosuje się tylko do tej rundy.\
        \nOto jakie znaczenie dla przebiegu walki ma SSS:\
        \n\
        \n1. Gdy zadałeś ranę potworowi\
        \n- jeśli masz SZCZĘŚCIE, to odejmujesz dodatkowo 2 od WYTRZYMAŁOŚCI potwora (łącznie -4).\
        \n- jeśli nie masz SZCZĘŚCIA, to odejmujesz łącznie 1.\
        \n2. Gdy potwór zadał ci ranę\
        \n- jeśli masz SZCZĘŚCIE, to odejmujesz łącznie 1 od swojej WYTRZYMAŁOŚCI\
        \n- jeśli nie masz SZCZĘŚCIA, to odejmujesz łącznie 3.')
    input(constants.input_sign)


def rules_5_increasing_character_levels():
    print(f'V. PODWYŻSZANIE POZIOMU CECH\
    \n\
    \nPodczas wędrówki, dzięki przygodom i walce, zmienia się poziom twoich cech.\
    \n1. ZRĘCZNOŚĆ - niewiele się zmienia\
    \n- zaczarowana broń podwyższa ZRĘCZNOŚĆ\
    \n- eliksir ZRĘCZNOŚCI przywraca poziom początkowy\
    \n2. WYTRZYMAŁOŚĆ - nieustannie się zmienia\
    \n- każdy posiłek (masz ich na starcie {constants.eatables_count}) dodaje {constants.eatable_W_load} punkty\
    \n- eliksir WYTRZYMAŁOŚCI przywraca poziom początkowy\
    \n3. SZCZĘŚCIE\
    \n- udane przygody dodają punkty\
    \n- eliksir SZCZĘŚCIA przywraca poziom początkowy, a nawet podnosi go o 1.\
    \nPoza tym przypadkiem, ZRĘCZNOŚĆ, WYTRZYMAŁOŚĆ i SZCZĘŚCIE nie mogą przekroczyć poziomu początkowego.')
    input(constants.input_sign)


def rules_6_provisions():
    print(f'VI. PROWIANT\
    \n\
    \nW plecaku masz Prowiant, który wystarcza na {constants.eatables_count} posiłków. Posiłek można zjeść TYLKO wówczas, gdy przewiduje to tekst.\
    \nZa jednym razem można zjeść tylko jeden posiłek. Spożywszy posiłek, dostajesz {constants.eatable_W_load} do swojej WYTRZYMAŁOŚCI.')
    input(constants.input_sign)


def rules_7_objective_of_the_expedition():
    print('VII. CEL WYPRAWY\
    \n\
    \nTwoim celem jest dotarcie do skarbca. Będziesz wędrował przez labirynt korytarzy.\
    \nOdwiedzisz wiele komnat, w których żyją różne istoty. Spotkają cię rozmaite niespodzianki.\
    \nZapewne wpadniesz w jakieś pułapki.\
    \nZnalezienie właściwej drogi i pokonanie potworów nie będzie łatwe.\
    \nZapewne będziesz musiał podjąć kilka wypraw, zanim uda ci się dotrzeć do celu.\
    \nZa każdym razem rysuj mapę podziemi. Bardzo ci pomoże.\
    \n')
    input(constants.input_sign)


def return_to_main_menu():
    print('POWODZENIA!')
    time.sleep(2)
    main_menu()


def sound_settings():
    functions.clear_terminal()

    choices = ['Dialogi', 'Efekty', 'Muzyka', 'Wróć']
    actions = [sound_settings_dialogs, sound_settings_effects, sound_settings_music, main_menu]
    print(f'{constants.def_txt_clr}USTAWIENIA DŹWIĘKU{constants.special_txt_clr}\
              \n{constants.def_txt_clr}Wybierz parametr z listy:')

    while True:
        for i, choice in enumerate(choices):
            print(f'({i + 1}) {choice}')
        choice_num = input(f'{constants.input_sign}')

        try:
            choice_num = int(choice_num)
            if choice_num < 1 or choice_num > len(choices):
                raise ValueError
            break
        except ValueError:
            print(f'/!/ \'{choice_num}\' nie jest poprawnym numerem')

    actions[choice_num - 1]()  # Wywołanie funkcji odpowiadającej wybranej pozycji
    functions.clear_terminal()
    sound_settings()


def sound_settings_dialogs():
    print(f"\rAktualny poziom głośności dla dialogów:", constants.def_action_volume, end="")


    while True:
        key = msvcrt.getch()
        if key == b'\xe0':
            arrow = msvcrt.getch()
            if arrow == b'H':
                constants.def_action_volume = min(constants.def_action_volume + 0.1, 1.0)
            elif arrow == b'P':
                constants.def_action_volume = max(constants.def_action_volume - 0.1, 0.0)
        else:
            break
        print(f'\rAktualny poziom głośności dla dialogów: {constants.def_action_volume:.2f}', end="")

    return constants.def_action_volume


def sound_settings_effects():
    print("\rAktualny poziom głośności dla efektów: ", constants.def_sfx_volume, end="")

    while True:
        key = msvcrt.getch()
        if key == b'\xe0':
            arrow = msvcrt.getch()
            if arrow == b'H':
                constants.def_sfx_volume = min(constants.def_sfx_volume + 0.1, 1.0)
            elif arrow == b'P':
                constants.def_sfx_volume = max(constants.def_sfx_volume - 0.1, 0.0)
        else:
            break
        print(f'\rAktualny poziom głośności dla efektów: {constants.def_sfx_volume:.2f}', end="")

    return constants.def_sfx_volume


def sound_settings_music():
    print("\rAktualny poziom głośności dla muzyki:", constants.def_bckg_volume, end="")

    while True:
        key = msvcrt.getch()
        if key == b'\xe0':
            arrow = msvcrt.getch()
            if arrow == b'H':
                constants.def_bckg_volume = min(constants.def_bckg_volume + 0.1, 1.0)
            elif arrow == b'P':
                constants.def_bckg_volume = max(constants.def_bckg_volume - 0.1, 0.0)
        else:
            break
        print(f'\rAktualny poziom głośności dla muzyki: {constants.def_bckg_volume:.2f}', end="")

    return constants.def_bckg_volume



# entering point
functions.rpar()

pygame.mixer.music.load(f'{constants.assets_audio_pth}/menu_background.mp3')
pygame.mixer.music.set_volume(constants.def_bckg_volume)
pygame.mixer.music.play(-1)

main_menu()

#  komenda do kompilacji: pyinstaller --onefile --name Dreszcz_v0.105 --icon icon.ico menu.py functions.py constants.py entities.py obj_class.py gamebook.py

