import pygame
from colorama import Fore

# /// text colors
def_txt_clr = Fore.LIGHTWHITE_EX
entity_txt_clr = Fore.RED
special_txt_clr = Fore.LIGHTMAGENTA_EX
combat_txt_clr = Fore.LIGHTCYAN_EX


# /// constants
and_his_name_is = '''
        ZZZZZZZ    BBBBBB       YYY     YYY     SSSSSS      ZZZZZZZZ      K     K     OOOOO     
              Z     B     B      YYY   YYY     S                  Z       K    K     O     O    
             Z      B     B       YYY YYY       SSS              Z        K   K     O       O    
            Z       BBBBBB         YYYYY             S          Z          KKK      O       O    
          Z         B     B         YYY            SSSS        Z          K   K     O       O    
         Z          B     B         YYY              S        Z           K    K     O     O    
        ZZZZZZZ    BBBBBB           YYY        SSSSSS        ZZZZZZZZ     K     K     OOOOO     
        '''
delay = 0.3
input_sign = '>>> '
player_name = 'Śmiałek'
count = 0
round_count = 0
z_init = z_count = 0
w_init = w_count = 0
s_init = s_count = 0


# /// selectors
count_potion = 2
d_lvl_e = 1
d_lvl_m = 1.2
d_lvl_h = 1.4
e_mult_choice = d_lvl_e
p_mult = 1
p_hit_val_ = -2*e_mult_choice
e_hit_val_ = -2*e_mult_choice
p_luck = None

# /// settings
debug_msg_enable = True
allow_skip_dub = False
automatic_battle = True


# - - - - - - - - -
# SOUND MIXING
# - - - - - - - - -
pygame.mixer.init(frequency = 44100, size = -16, channels = 1, buffer = 2**12)
# - - - - - - - - -
def_action_volume = 1
def_sfx_volume = 0.8
def_bckg_volume = 0.8

assets_audio_pth = 'Assets/Audio'

# /// EKWIPUNEK
# - - - - - - - - -
# - - - - - - - - -
# /// głowy ekwipunek
# - - - - - - - - -
init_eatables_count = eatables_count = 8    # /// początkowa ilość posiłków
eatable_W_load = 4                          # /// ile ładunków wytrzymałości w jednym posiłku
gold_amount = 0                             # /// początkowa ilość sztuk złota
# - - - - - - - - -
main_eq =   {'slot0': 'plecak na Prowiant',
            'slot1': f'prowiant ({eatables_count} porcji)',
            'slot2': 'tarcza',
            'slot3': 'miecz',
            'slot4': f'złoto({gold_amount} sztuk)',
            'slot5': 'empty',
            'slot6': 'empty',
            'slot7': 'empty',
            'slot8': 'empty',
            }
# - - - - - - - - -
# /// ekwipunek na numerowane klucze
# - - - - - - - - -
keys_eq =   {'slot0': 'empty',
            'slot1': 'empty',
            'slot2': 'empty',
            'slot3': 'empty',
            'slot4': 'empty',
            'slot5': 'empty',
            'slot6': 'empty',
            'slot7': 'empty',
            'slot8': 'empty',
            }




# sortowanie

win_path = ''
difficulty_ = ''
init_round_count = 0