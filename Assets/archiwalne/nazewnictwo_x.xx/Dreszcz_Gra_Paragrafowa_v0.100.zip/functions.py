import random, time, pygame, os
import constants, paragraphs
from colorama import Fore
from objects import Entity, Door, Room
import subprocess


def clear_terminal():
    subprocess.call('cls' if os.name == 'nt' else 'clear', shell=True)


def dub_play(audio_file_id):
    def_action_volume = constants.def_action_volume
    current_sound = pygame.mixer.Sound(audio_file_id)
    current_sound.set_volume(def_action_volume)
    current_sound.play()


# /// Drobne
def loading(duration):  # loading script
    t_end = time.time() + 1 * duration-1
    steps = [".", "..", "..."]
    while time.time() < t_end:
        for i in steps:
            print('\r' + i, end='')
            time.sleep(0.3)


def name_randomizer():
    pieces_a = ['Bo', 'Ma', 'I', 'So', 'Li', 'Pa', 'Na', "Ge", 'Di', 'Ho']
    pieces_b = ['de', 'hwa', 'ns', 'ry', 'wo', 'z', 'le', 'r', 'kho', 'sa']
    pieces_c = ['er', 'gon', 'alt', 'tre', 'e', 'on']
    constants.player_name = random.choice(pieces_a) + random.choice(pieces_b) + random.choice(pieces_c)
    return constants.player_name


def rpar():
    constants.z_init = constants.z_count = random.randint(1, 6) + 6
    constants.w_init = constants.w_count = random.randint(2, 12) + 12
    constants.s_init = constants.s_count = random.randint(1, 6) + 6
    return constants.z_init, constants.z_count, constants.w_init, constants.w_count, constants.s_init, constants.s_count


def pth_selector(path_strings, actions):
    time.sleep(constants.delay)
    print(f'{constants.def_txt_clr}')
    for i, path in enumerate(path_strings):
        print(f'{i+1} · {path}')
        time.sleep(constants.delay)
    odp = input(f"\
    \n{constants.input_sign} ")
    pygame.mixer.stop()
    try:
        odp = int(odp)
        if odp == 0:
            print(f'/!/ {constants.special_txt_clr}Wybór nie może być równy zeru.{constants.def_txt_clr}')
        elif odp < 0:
            print(f'/!/ {constants.special_txt_clr}Wybór nie może być ujemny.{constants.def_txt_clr}')
        elif odp > len(path_strings):
            print(f'/!/ {constants.special_txt_clr}Nie ma wyboru o numerze: {odp}{constants.def_txt_clr}')
        else:
            clear_terminal()
            eval(actions[odp-1])
    except ValueError:
        print(f'/!/ {constants.special_txt_clr}Wybierz numer z listy.{constants.def_txt_clr}')
    pth_selector(path_strings, actions)


def difficulty_selector(lvl_choice):
    e_mult_choice = lvl_choice
    print(f"mnożnik wytrzymałości wroga = {e_mult_choice}")
    return e_mult_choice


def kill():
    print("Koniec gry")
    time.sleep(constants.delay)
    print()
    pygame.mixer.music.load(f'{constants.assets_audio_pth}/main_background.mp3')
    pygame.mixer.music.set_volume(constants.def_bckg_volume)
    pygame.mixer.music.play(-1)
    menu.main_menu()


def win():
    print("GRATULACJE, WYGRAŁEŚ!!!")
    time.sleep(2)
    menu.main_menu()


def check_for_luck():
    print(f'{constants.special_txt_clr}Sprawdzam czy masz szczęście:')
    loading(3)
    cfl_val = random.randint(2, 12)
    if cfl_val <= constants.s_count:
        print('\rUff, masz szczęscie.')
        p_luck = True
    elif cfl_val > constants.s_count:
        print('\rNie masz szczęścia!')
        p_luck = False
    constants.s_count -= 1
    time.sleep(0.8)
    print()
    return p_luck


def check_for_gold_amount(true_path, false_path, req_amount):
    if constants.gold_amount >= req_amount:
        eval(true_path)
    else:
        print('Nie masz wystarczającej ilości złota.')
        eval(false_path)

def eatables():
    print(f"{constants.special_txt_clr}Czy chcesz zjeśc prowiant? (+4 Wytrzymałość) (tak/nie)")
    print(f"/// Wytrzymałość: {constants.w_count}/{constants.w_init}")
    print(f"/// Prowiant: {constants.eatables_count}/{constants.init_eatables_count}")
    odp = input(f"{constants.input_sign} ")
    print()
    if odp.lower() in {'tak', 't', 'y', 'yes'}:
        if constants.w_count < constants.w_init:
            constants.eatables_count += -1
            if constants.eatables_count >= 0:
                if constants.w_count == constants.w_init-1:
                    # + 1
                    print(f"Wytrzymałość + {constants.eatable_W_load - 3}")
                    constants.w_count += constants.eatable_W_load - 3
                elif constants.w_count == constants.w_init-2:
                    # + 2
                    print(f"Wytrzymałość + {constants.eatable_W_load - 2}")
                    constants.w_count += constants.eatable_W_load - 2
                elif constants.w_count == constants.w_init-3:
                    # + 3
                    print(f"Wytrzymałość + {constants.eatable_W_load - 1}")
                    constants.w_count += constants.eatable_W_load - 1
                else:
                    # + 4
                    print(f"Wytrzymałość + {constants.eatable_W_load}")
                    constants.w_count += constants.eatable_W_load
                print(f"/// Wytrzymałość: {constants.w_count}/{constants.w_init}")
                time.sleep(constants.delay)
                print(f"/// Prowiant: {constants.eatables_count}/{constants.init_eatables_count}{constants.def_txt_clr}")
                time.sleep(constants.delay)
                print(f"{constants.def_txt_clr}")
            else:
                print("Nie masz już prowiantu.")
        else:
            print(f"Wytrzymałość nie może być większa od wartości początkowej: {constants.def_txt_clr}{constants.w_init}")
    elif odp.lower() in {'nie', 'n', 'no'}:
        print("Nie zjeść prowiantu.")
        time.sleep(constants.delay)
        print(f"{constants.def_txt_clr}")
    else:
        print("Wpisz tak/nie")
        time.sleep(constants.delay)
        eatables()

    return constants.w_count, constants.eatables_count

def show_equipment_list():
    for key, value in constants.main_eq.items():
        if key != constants.main_eq['slot1']:
            print(f"- {value}")
        else:
            print(f"- {value} sss")
    input(f"{constants.input_sign} ")
    time.sleep(constants.delay)
    print()


def eq_change(new_item_name):
    print(f"/// {constants.special_txt_clr}Zdobyto nowy przedmiot: {new_item_name}{constants.def_txt_clr}")


def show_player_stats():
    print(f'\
    \n{constants.combat_txt_clr}Statystyki gracza:\
        \nWytrzymałość: {constants.w_count}/{constants.w_init}\
        \nZręczność: {constants.z_count}/{constants.z_init}\
        \nSzczęście: {constants.s_count}/{constants.s_init}')
    time.sleep(2)


def show_entity_stats(entity):
    print(f'\
    \nStatystyki {entity.name}:\
        \nWytrzymałość: {entity.entity_w_count}/{entity.entity_w_init}\
        \nZręczność: {entity.entity_z_count}/{entity.entity_z_init}')
    time.sleep(2)


def stats_change(attribute_name, variable ,amount):
    variable += amount
    time.sleep(constants.delay)
    print(f'{constants.special_txt_clr}/// {attribute_name} +{amount} >>> {variable}{constants.def_txt_clr}')
    return constants.w_count, constants.z_count, constants.s_count, constants.eatables_count, constants.gold_amount, variable


# - - - - - - - - -
# /// COMBAT
# - - - - - - - - -
def combat_init(entity, state, esc_possible, escape_id, stay_id, win_path_id):
    pygame.mixer.music.fadeout(1500)
    pygame.mixer.music.load(f'{constants.assets_audio_pth}/combat_2_background.mp3')
    pygame.mixer.music.set_volume(constants.def_bckg_volume)
    pygame.mixer.music.play(-1)
    win_path = win_path_id
    p_w_count = constants.w_count
    e_w_count = entity.entity_w_count

    to_the_end = False

    time.sleep(constants.delay)

    show_player_stats()
    show_entity_stats(entity)

    input(f'\
    \n{constants.combat_txt_clr}Rozpocznij walkę! {constants.input_sign}')
    combat_main(entity, state, esc_possible, escape_id, stay_id, to_the_end, p_w_count, e_w_count, win_path)



def combat_main(entity, state, esc_possible, escape_id, stay_id, to_the_end, p_w_count, e_w_count, win_path):
    if e_w_count <= 0:
        pygame.mixer.music.fadeout(1500)
        pygame.mixer.music.load(f'{constants.assets_audio_pth}/main_background.mp3')
        pygame.mixer.music.set_volume(constants.def_bckg_volume)
        pygame.mixer.music.play(-1)
        state = False
        print()
        dub_play(f'{constants.assets_audio_pth}/combat_win.wav')
        print(f'{constants.combat_txt_clr}Pokonałeś {Fore.LIGHTRED_EX}{entity.name}{constants.combat_txt_clr}!\
        \n')
        time.sleep(constants.delay)
        show_player_stats()
        eval(win_path)
    elif p_w_count <= 0:
        print()
        dub_play(f'{constants.assets_audio_pth}/combat_die.mp3')
        print(f'Zostałeś zabity przez {Fore.LIGHTRED_EX}{entity.name}{constants.combat_txt_clr}!\
        \n')
        kill()
    else:
        combat_round(entity, state, esc_possible, escape_id, stay_id, to_the_end, p_w_count, e_w_count, win_path)
    return state, constants.w_count, constants.count



def combat_round(entity, state, esc_possible, escape_id, stay_id, to_the_end, p_w_count, e_w_count, win_path):
    constants.count += 1
    print(f'\
    \n{constants.combat_txt_clr}Runda: {constants.count}{constants.combat_txt_clr}')
    p_w_count = constants.w_count
    e_w_count = entity.entity_w_count
    a = random.randint(2, 12) + entity.entity_z_count
    b = random.randint(2, 12) + constants.z_count
    loading(2)
    if state:
        if a > b:
            # jeśli wróg wygrał rundę
            if constants.w_count > 0:
                constants.w_count += constants.e_hit_val_
                dub_play(f'{constants.assets_audio_pth}/dreszcz_enemy_hit.mp3')
                print(f"{Fore.LIGHTRED_EX}{entity.name}{constants.combat_txt_clr} zadał cios!")
                print(f"{constants.special_txt_clr}/// Wytrzymałość {Fore.LIGHTYELLOW_EX}{constants.player_name}{constants.special_txt_clr}: {constants.w_count}/{constants.w_init}")
                time.sleep(constants.delay)
            elif constants.w_count <= 0:
                pass
        elif a < b:
            # jeśli gracz wygrał rundę
            if entity.entity_w_count > 0:
                entity.entity_w_count += constants.p_hit_val_
                dub_play(f'{constants.assets_audio_pth}/dreszcz_player_hit.mp3')
                print(f"{Fore.LIGHTYELLOW_EX}{constants.player_name}{constants.combat_txt_clr} zadał cios!")
                print(f"{constants.special_txt_clr}/// Wytrzymałość {Fore.LIGHTRED_EX}{entity.name}{constants.special_txt_clr}: {entity.entity_w_count}/{entity.entity_w_init}")
                time.sleep(constants.delay)
        else:
            # jeśli remis
            dub_play(f'{constants.assets_audio_pth}/dreszcz_remis.mp3')
            print(f'{constants.special_txt_clr}Remis!')
            time.sleep(constants.delay)
        if esc_possible:
            if not to_the_end:
                # /// wybór ucieczka czy nie
                ecape_opt = "{0}{1}".format(escape_id, (
                    "entity, state, esc_possible, escape_id, stay_id, to_the_end, p_w_count, e_w_count)"))
                stay_opt = "{0}{1}".format(stay_id, (
                    "entity, state, esc_possible, escape_id, stay_id, to_the_end, p_w_count, e_w_count, win_path)"))
                time.sleep(constants.delay)
                print()
                print(
                    f"{constants.def_txt_clr}Uciekasz czy zostajesz i walczczysz dalej? {constants.special_txt_clr}/Wytrzymałość - 2/{constants.def_txt_clr}:\
                      \nuciekasz        = <enter>\
                      \nwalczysz dalej  = wpisz cokolwiek")
                odp = input(f"tak/nie {constants.input_sign} ")
                print()
                if len(odp) == 0:
                    print(f"{constants.special_txt_clr}Wytrzymałość: {constants.w_count} {constants.input_sign} {constants.w_count - 2}{constants.def_txt_clr}")
                    constants.w_count -= 2
                    time.sleep(constants.delay)
                    print()
                    exec(ecape_opt)
                elif len(odp) > 0:
                    time.sleep(constants.delay)
                    print()
                    exec(stay_opt)
            else:
                pass
        else:
            pass
    else:
        pass
    combat_main(entity, state, esc_possible, escape_id, stay_id, to_the_end, p_w_count, e_w_count, win_path)
