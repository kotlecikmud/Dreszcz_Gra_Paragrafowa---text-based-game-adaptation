import pygame, time, random
import constants, functions, entities, objects
# - - - - - - - - -
# /// PARAGRAPHS
# - - - - - - - - -
def _xx():  # placeholder
    print('placeholder function, returning to _01()')
    time.sleep(3)
    _01()
# - - - - - - - - -
def par_00():
    functions.dub_play(f'{constants.assets_audio_pth}/dreszcz_intro.mp3')
    print(f'\r{constants.def_txt_clr}Wędrując po podziemiach będziesz znajdował inne rodzaje broni i przedmioty.\
                        \nPamiętaj, że - poza mieczem - każda broń może być wykorzystana tylko raz.\
                        \nPodobnie, znajdowane przedmioty są jednorazowego użytku.\
                        \nMożesz zabrać ze sobą jedną butelkę eliksiru.\
                        \n')
    time.sleep(19)

    while True:
        functions.dub_play(f'{constants.assets_audio_pth}/elxr_choice.wav')
        functions.clear_terminal()
        choice = input(f'{constants.special_txt_clr}Wybierz eliksir:\
            \n1. Zręczności\
            \n2. Wytrzymałości\
            \n3. Szczęścia\
            \n{constants.input_sign}')
        if choice == '1':
            potion = constants.Z_potion
            break
        elif choice == '2':
            potion = constants.W_potion
            break
        elif choice == '3':
            potion = constants.S_potion
            break
        else:
            functions.clear_terminal()
            time.sleep(2)
            print(f"{constants.special_txt_clr}Niepoprawny wybór.")

    print(f"/// eliksir {potion} = {constants.count_potion}/2")
    time.sleep(constants.delay)


    pygame.mixer.music.load(f'{constants.assets_audio_pth}/main_background.mp3')
    pygame.mixer.music.set_volume(constants.def_bckg_volume)
    pygame.mixer.music.play(-1)
    functions.dub_play(f'{constants.assets_audio_pth}/dreszcz_p_000.mp3')
    time.sleep(constants.delay)


    print(f"{constants.def_txt_clr}Hej, Śmiałku!")
    time.sleep(constants.delay)
    print('To o Tobie mówią, że w Twoich żyłach zamiast krwi płynie lodowata woda,\
    \na twoje mięśnie są z najszlachetniejszej stali?\
    \nJeśli tak, spójrz w stronę zachodzącego słońca.\
    \nTam, na rubieżach królestwa Almanhagor, rozpoczynają się niezbadane Podziemia.\
    \nTylko Ty możesz wydrzeć ich Wielką Tajemnicę.')

    path_strings = [f'Ruszaj {constants.input_sign}']
    actions = ['paragraphs._01()']
    functions.pth_selector(path_strings, actions)


def _01():
    print('Wejście do podziemi jest szerokie, obrośnięte trawą i bujnymi krzewami.\
    \nPoprawiasz ubranie i ekwipunek.\
    \nZapal latarnię! Wchodzisz do korytarza. Jest wysoki, nie musisz się schylać.\
    \nProwadzi prosto na północ. Wkrótce dochodzisz do skrzyżowania.\
    \nMa ono kształt litery T. Odnogi prowadzą na zachód, wschód i południe (skąd przyszedłeś).')
    functions.dub_play(f'{constants.assets_audio_pth}/dreszcz_p_001.mp3')
    path_strings = [f'{constants.input_sign} ']
    actions = ['paragraphs._25()']
    functions.pth_selector(path_strings, actions)


def _02():
    print('Kopnij drzwi. Otwierają się i uderzają o skałę.\
    \nWchodzisz do środka z mieczem gotowym do zadania ciosu.\
    \nNa pewno potwór nigdzie się nie ukrywa. Czuje się zbyt potężny.\
    \nTak, widzisz go przed sobą. Stoi na szeroko rozstawionych nogach.\
    \nOn też ma miecz. Czub wbił się w piasek. Opiera dłonie na rękojeści.\
    \nCzeka. Ty nie czekaj! Jeśli masz hełm, załóż go koniecznie, zapewni ci +3W na czas trwania tej walki.')
    functions.dub_play(f'{constants.assets_audio_pth}/dreszcz_p_002.mp3')
    # initiate combat with entity_002
    functions.combat_init(entities.entity_002, True, entities.entity_002.esc_possible, 'paragraphs._372(', '', 'paragraphs._380()')


def _03():
    print('Twoja cierpliwość - a szczególnie zapasy złota - są na wyczerpaniu.\
    \nA może inaczej? Starzy mieszkańcy podziemi mówią, że Smok ma swoje słabe strony.\
    \nSzczególnie słaba jest jego lewa strona, gdzie nosi wór na pieniądze i złoto.\
    \nMoże by tak spróbować jeszcze raz, płacąc ponad taryfę (13 sztuk złota)?')
    functions.dub_play(f'{constants.assets_audio_pth}/dreszcz_p_003.mp3')
    # path_strings = ['Spróbuj jeszcze raz(wymagane conajmniej 13 sztuk złota)', 'Wyciągnij z plecaka linę', 'Podejdź do mostu', 'Spróbuj przeskoczyć przez rozpadlinę (przynajmniej 18W i 9Z)']
    # actions = ['paragraphs._136()', 'paragraphs._13()', 'paragraphs._269()', 'paragraphs._74()', 'paragraphs._110()']
    # functions.pth_selector(path_strings, actions)


def _04():
    print('KRASNOLUDY prowadzą cię do stołu. Przynoszą na półmiskach czystą, zieloną sałatę.\
    \nStawiają pucharki. Rozlewasz napój. Kątem oka spostrzegasz,\
    \nże dwa KRASNOLUDY wychodzą z pokoju wschodnimi drzwiami.\
    \nRozpinasz rzemień, ukradkiem wyciągasz miecz i kładziesz go przed sobą na stole.\
    \nZapada cisza. KRASNOLUDY bacznie cię obserwują.\
    \nTy patrzysz im prosto w oczy. Milczenie przeciąga się')
    functions.dub_play(f'{constants.assets_audio_pth}/dreszcz_p_004.mp3')
    path_strings = ['Chwytasz za miecz i atakujesz', 'Postanawiasz czekać dalej']
    actions = ['paragraphs._318()', 'paragraphs._295()']
    functions.pth_selector(path_strings, actions)


def _05():
    print('Lubisz walkę? Tak? To wspaniale. Przyjrzyj się więc dokładnie.\
    \nOd lewej stoją: SZKIELET, ZOMBI i LUDOJAD. Wystarczy?')
    functions.dub_play(f'{constants.assets_audio_pth}/dreszcz_p_005.mp3')
    path_strings = ['tak', 'nie']
    actions = ['paragraphs._312()', 'paragraphs._140()']
    functions.pth_selector(path_strings, actions)


def _06():
    print('Możesz rozejrzeć się po komnacie. Ech, toż to prawdziwa zbrojownia. krasnali ziemnych.\
    \nNa ścianach wiszą tarcze, niektóre ciężkie, u góry i u dołu zakończone ostrymi szpicami,\
    \ninne ozdobne, obite czerwono-złotymi płytkami: są też lekkie tarcze skórzane.\
    \nNa stojaku błyszczą miecze. Te najdłuższe, cienkie, to jedyna skuteczna broń przeciw wiedźmom.\
    \nMiecze kamienne o gładkim brzeszczocie i ostrym jak igła czubie przeznaczone są do walki z płazurami.\
    \nNie wykonuje się nimi zamachów, lecz spuszcza z góry, by przeszywały cielska tych potworów.\
    \nPrzy samej ziemi widzisz poustawiane w rzędzie malutkie mieczyki gremlinów, krasnali ziemnych.\
    \nGdybyś widział jaki potrafią robić z nich użytek!\
    \nNa wschodniej ścianie wiszą drewniane półki zastawione całą kolekcją hełmów.\
    \nSą hełmy do pojedynków turniejowych, wyściełane żółtą trawą, są ciężkie hełmy z podnoszoną przyłbicą.\
    \nNa najwyższej półce stoją trzy - chyba - garnki. Nie, to są hełmy\
    \ndo walki w pomieszczeniach albo korytarzach wypełnionych żrącym gazem.\
    \nCzubkiem miecza podrzucasz jakieś skórzane płaty.\
    \nTo czapa, którą okrutne potwory zakładają na łeb torturowanym przez siebie istotom.\
    \nRozglądasz się dalej. Pod ścianami stoi, albo leży mnóstwo broni.\
    \nNawet nie wiesz komu i do czego służy. Widzisz ciężki młot na drewnianym stylisku,\
    \nzapewne zdobyty kiedyś na goblinach, a także kościany kordelas w skórzanym futerale.\
    \nMożesz zabrać dwie rzeczy.')
    functions.dub_play(f'{constants.assets_audio_pth}/dreszcz_p_006.mp3')
    input("   ///   mechanika wyboru dwóch żeczy i dodania ich do ewipunku")
    path_strings = [f'{constants.input_sign} ']
    actions = ['paragraphs._115()']
    functions.pth_selector(path_strings, actions)


def _07():
    print("'Może ma Pan na składzie coś, co mógłbym ofiarować w prezencie?' - mówisz.\
    \n'Jak mógłbym nie mieć? Jestem zawsze przygotowany na takie zachcianki.\
    \nMam uroczy drewniany pal i słój żrącego pyłu. Zapakować ze wstążeczką?'.")
    path_strings = [f'{constants.input_sign} ']
    actions = ['paragraphs._219()']
    functions.pth_selector(path_strings, actions)


def _08():
    print("Zaglądasz do komnaty. Drzwi lekko się uchylają. Co widzisz?\
    \nJakiś dziwnystwór biega jak oszalały od ściany do ściany. Nie wygląda groźnie.\
    \nZa pas, wkieszenie, do cholew powtykane ma rozmaitej długości i różnego gatunku kości.\
    \nWchodzisz do środka. 'Czemu tak biegasz, biedaku?' - pytasz.\
    \n-'O, panie, co jaim zrobiłem? Taki raban o tych parę kostek! Moi bracia, gobliny upolowali kilkakocmołuchów.'\
    \nJak pewnie wiesz, kocmołuchy to największy przysmak goblinów. Niemogłem sobie odmówić.\
    \nPodkradłem się i gwizdnąłem kilka kostek. Siadłem tu, byje sobie zjeść,\
    \na te bestie wyśledziły mnie i zaraz tu wpadną. O, już biegną.'\
    \nIgoblin znów zaczyna szaleć. Bierzesz go za ramię i stajesz na środku komnaty.\
    \nZa chwilę w drzwiach pojawia się stado goblinów.")
    path_strings = ['Walcz u boku prześladowanego stwora przeciw zgrai jego współplemieńców', 'Ratuj się Ucieczką']
    actions = ['paragraphs._210()', 'paragraphs._98()']
    functions.pth_selector(path_strings, actions)


def _09():
    print('Przygotowujesz się, by walnąć KRASNALA drewnianym palem. On spostrzega to.\
    \n"Och, co za piękny pal" - mówi - "Sprzedaj mi go za 20 sztuk złota".')
    path_strings = ['Sprzedaj kamień krasnalowi', 'Nie sprzedawaj kamienia']
    actions = ['paragraphs._289()', 'paragraphs._375()']
    functions.pth_selector(path_strings, actions)


def _10():
    print('KRASNOLUDY zapraszają cię, byś usiadł przy stole. Uśmiechają się.\
    \n"Nareszcie jakiś kulturalny potwór" - mówią. "Wszyscy tylko wpadają tu, wyrywają główki\
    \nsałaty i zwiewają. Ale nie mamy im tego za złe. Przynajmniej komuś przyda się\
    \nnasze warzywko, he, he". Zamyśliłeś się chwilę nad tym "he, he", a tu już\
    \nKRASNOLUDY zaczynają snuć opowieści. Niewielu z nich zapuszczało się\
    \nkiedykolwiek w dalsze rejony podziemi. Ci, którzy wrócili, mówią,\
    \nże najstraszniejszą rzeczą którą można spotkać jest ogień. Błąka się też po\
    \nlabiryncie tłusty Smok. Podobno jest bardzo groźny, choć niektórzy powiadają,\
    \nże jest przekupny.\
    \n\
    \nSłuchasz tych opowieści, ale ciągle coś nie daje ci spokoju.\
    \n   ///   Jeśli szedłeś ścieżką przez środek komnaty /../../../')
def _11():
    print('Przejście stoi otworem. Do tej komnaty nie ma żadnych drzwi.\
    \nWchodzisz więc śmiało.\
    \n"Cześć" - jedno słowo a ty nieruchomiejesz.\
    \n"Cześć, Śmiałku, he, he" - w rogu komnaty siedzi mały, pomarszczony stwór.\
    \n"Pić ci się chce? Weź sobie wody. Dobra, chłodna woda. Palce lizać i obgryzać, he, he".\
    \nNa środku komnaty stoi kamienna fontanna. Woda otacza figurkę jakiejś niezwykłej istoty.\
    \nZ pyszczka wycieka jej mały strumyk wody. "...Są prawdziwe skarby. Chcesz skosztować wody?\
    \nTo dobra chłodna woda". Stoisz jak wryty. Ten mały śmieszny stwór zabił ci ćwieka.\
    \nCałkiem straciłeś rezon. No, decyduj się:')
    functions.dub_play(f'{constants.assets_audio_pth}/dreszcz_p_011.mp3')
    path_strings = ['idziesz od razu po wodę', 'dobierasz się do stwora']
    actions = ['paragraphs._45()', 'paragraphs._192()']
    functions.pth_selector(path_strings, actions)
def _12():
    print('Wyjmujesz zaczarowany szmaragd. Ból rozrywa ci plecy, pęka skórzana kurtka.\
    \nZ pleców wyrastają ci szerokie, sinoszare skrzydła. Unosisz się. Lądujesz na\
    \nwymarzonym brzegu przepaści. Czar pryska.')
    functions.dub_play(f'{constants.assets_audio_pth}/dreszcz_p_012.mp3')
    path_strings = [f'{constants.input_sign} ']
    actions = ['paragraphs._288()']
    functions.pth_selector(path_strings, actions)
def _13():
    print('Nie musisz się rozglądać. Od razu powiem ci wszystko. W tej komnacie czai się\
    \nWILKOŁAK. Wie, że tu jesteś. Robisz kilka kroków w mrok Za wyłomem skalnym\
    \ndostrzegasz świecący punkt. Ukradkiem sięgasz po miecz. Robisz kolejne kroki.\
    \nTeraz już są dwa punkty. Łoskot. Zza skały wyskakuje on. W smudze światła,\
    \nktóra pada przez uchylone drzwi do pieczary, widzisz tylko białe kły i zielone oczy.\
    \nBłyskawicznie chwytasz oburącz swój miecz. Robisz zamach...\
    \ni zastygasz nieruchomo. Zielone ślepia paraliżują twe ciało')
    functions.stats_change('Wytrzymałość', constants.w_count, -2)
    print('Ale to tylko chwila. Wielkimi susami biegniesz w kierunku potwora')
    path_strings = [f'{constants.input_sign} ']
    actions = ['paragraphs._126()']
    functions.pth_selector(path_strings, actions)
def _14():
    path_strings = ['Wychodzisz północnymi drzwiami', 'Wychodzisz wschodnimi drzwiami']
    actions = ['paragraphs._197()', 'paragraphs._39()']
    functions.pth_selector(path_strings, actions)
def _15():
    path_strings = ['Rezygnujesz z przepłynięcia jeziora', 'Decydujesz się podjąć próbę przepłynięcia jeziora']
    actions = ['paragraphs._241()', 'paragraphs._113()']
    functions.pth_selector(path_strings, actions)
    # print('Jeśli rezygnujesz z przepłynięcia jeziora - patrz 241\
    # \nNatomiast jeśli decydujesz się podjąć próbę przepłynięcia jeziora, zapisz numer niniejszego paragrafu i patrz 113')
def _16():
    print('Wychodzisz na korytarz. Po pewnym czasie skręca on na południe. W tym samym\
    \nmiejscu możesz usiąść i zjeść Prowiant.')
    functions.eatables()
    print('Ruszasz dalej. Idziesz na południe do czasu, gdy tunel skręca na znowu zachód.\
    \nW odległości dwudziestu kroków widzisz przed sobą wejście do komnaty.')
    path_strings = [f'{constants.input_sign} ']
    actions = ['paragraphs._80()']
    functions.pth_selector(path_strings, actions)
def _17():
    path_strings = ['Chcesz zobaczyć co za nimi jest', 'Wolisz się wycofać']
    actions = ['paragraphs._265()', 'paragraphs._50()']
    functions.pth_selector(path_strings, actions)
def _18():
    print(f'{constants.def_txt_clr}Wchodzisz do małej pieczary, przylegającej do komnaty. Za tobą trzy ZŁE.\
    \nStaruszek został w pokoju. Za wyłomem skalnym widzisz przykutego do skały\
    \ngremlina. Biedaczysko ledwie zipie. ZŁY bierze cię za ramię i odprowadza na\
    \nodległość dziesięciu kroków od gremlina. Daje ci w garść sześć strzałek. ZŁY też\
    \nma sześć. Pokazuje palcem w stronę zakutego gremlina. To w niego należy celować!\
    \nChcesz grać?')
    path_strings = ['Jeśli tak, pamiętaj że musisz mieć przynajmniej 5 sztuk złota', 'Wycofujesz się']
    actions = ['paragraphs._211()', 'paragraphs._286()']
    functions.pth_selector(path_strings, actions)
def _19():
    global eatables_count
    global s_count
    print(f'{constants.def_txt_clr}KRASNOLUDY żegnają cię serdecznie i wręczają na drogę dwie główki sałaty.\
    \nOdprowadzają cię do wschodnich drzwi.')
    functions.stats_change('Prowiant', eatables_count, 1)
    functions.stats_change('Szczęście', s_count, 2)
    path_strings = [f'{constants.input_sign} ']
    actions = ['paragraphs._141()']
    functions.pth_selector(path_strings, actions)
def _20():
    print('Po długim marszu dochodzisz do jakiejś wielkiej jaskini.\
    \nNie, to raczej bezkresna równina. Zapewne sławetne Szalone Pola.\
    \nSłyszysz jakiś hałas. Co sił wnogach biegniesz na zachód.\
    \nJednak potwory dopadają cię.')
    path_strings = [f'{constants.input_sign} ']
    actions = ['paragraphs._238a()']
    functions.pth_selector(path_strings, actions)
def _21():
    print('')
def _22():
    print('')
def _23():
    print('')
def _24():
    print('')
def _25():
    print('Na kamieniu siedzi stary człowiek. Radzi ci iść na zachód,\
    \na później na kilku najbliższych skrzyżowaniach skręcać w prawo.')
    functions.dub_play(f'{constants.assets_audio_pth}/dreszcz_p_025.mp3')
    path_strings = ['Idziesz na zachód', 'Wybierasz drogę prowadzącą na wschód']
    actions = ['paragraphs._200(door_200.door_state)', 'paragraphs._44()']
    functions.pth_selector(path_strings, actions)
def _26():
    _xx()
def _27():
    _xx()
def _28():
    global w_count
    print('Podnieś wielki kamień leżący przy ścianie.')
    if w_count >= 18:
        _177()
    else:
        _330()
def _29():
    print('Potykasz się na kamyku. Miecz brzęknął o skałę. ORK podnosi głowę.\
    \nZauważył cię. Rzuca się do walki.')
    functions.dub_play(f'{constants.assets_audio_pth}/dreszcz_p_029.mp3')
    path_strings = [f'{constants.input_sign} ']
    actions = ['paragraphs._116a()']
    functions.pth_selector(path_strings, actions)
def _30():
    _xx()
def _31():
    _xx()
def _32():
    _xx()
def _35():
    _xx()
def _39():
    print('Dochodzisz do skrzyżowania. Jego odnogi prowadzą na:')
    input(objects.room_331.visit_in_turn)
    path_strings = ['zachód', 'północ', 'południe']
    actions = ['paragraphs._331(objects.room_331.visit_in_turn)', 'paragraphs._228()', 'paragraphs._146()']
    functions.pth_selector(path_strings, actions)
def _44():
    print("Idziesz na wschód. Widzisz przed sobą solidne drzwi.\
    \nPróbujesz je otworzyć. Nie ustępują.")
    functions.dub_play(f'{constants.assets_audio_pth}/dreszcz_p_044.mp3')
    path_strings = ['Rezygnujesz', 'Wyważasz drzwi']
    actions = ['paragraphs._75()', 'paragraphs._105()']
    functions.pth_selector(path_strings, actions)
def _45():
    print('Kierujesz się w stronę fontanny. Nabierasz wody. Jest zaczarowana.\
    \nChowasz naczynie do plecaka. Spostrzegasz, że fontanna jest już pusta.')
    functions.stats_change('Szczęscie', constants.s_count, 2)
    _xx()
def _50():
    print("Zbliżasz się do skrzyżowania.\
    \nMożesz iść:")
    path_strings = ['północ', 'wschód', 'zachód']
    actions = ['paragraphs._310()', 'paragraphs._130()', 'paragraphs._64()']
    functions.pth_selector(path_strings, actions)
def _56():
    print('Ponownie próbujesz wyważyć drzwi. Znowu bezskutecznie.')
    functions.dub_play(f'{constants.assets_audio_pth}/dreszcz_p_056.mp3')
    functions.stats_change('Wytrzymałość', constants.w_count, -1)
    path_strings = [f'{constants.input_sign} ']
    actions = ['paragraphs._75()']
    functions.pth_selector(path_strings, actions)
def _59():
    print('Wchodzisz, ale niczego tu nie znajdujesz.\
    \nCzy znasz inne wyjście z tej komnaty niż to, którym właśnie wszedłeś?')
    path_strings = ['tak', 'nie']
    actions = ['paragraphs._14()', 'paragraphs._70()']
    functions.pth_selector(path_strings, actions)
def _64():
    print("Zbliżasz się do skrzyżowania. Możesz iść w każdym z czterech kierunków.\
    \nWybierz kierunek:")
    path_strings = ['zachód', 'północ', 'wschód', 'południe']
    actions = ['paragraphs._296()', 'paragraphs._264()', 'paragraphs._284()', 'paragraphs._224()']
    functions.pth_selector(path_strings, actions)
def _69a():
    print('Sam tego chciałeś. Pod ścianą komnaty siedzą dwa koszmarne upiory.\
    \nTakie spotkanie może zakończyć się tylko walką, najpierw z jednym, a później z drugim potworem.')
    # initiate combat with entity_069_1
    functions.combat_init(entities.entity_069_1, True, entities.entity_069_1.esc_possible, '', '', '_69b()')
def _69b():
    print(f'{constants.def_txt_clr}Ledwo pokonałeś pierwszego upiora a już zabierasz się za drugiego.')
    # initiate combat with entity_069_2
    functions.combat_init(entities.entity_069_2, True, entities.entity_069_2.esc_possible, '', '', '_69c()')
def _69c():
    print(f'{constants.def_txt_clr}Możesz przeszukać komnatę.')
    path_strings = ['tak', 'nie']
    actions = ['paragraphs._305()', 'paragraphs._291()']
    functions.pth_selector(path_strings, actions)
def _75():
    print('Wycofujesz się. Wracasz w stronę skrzyżowania. Mijasz starca.')
    path_strings = [f'{constants.input_sign} ']
    actions = ['paragraphs._200(door_200.door_state)']
    functions.pth_selector(path_strings, actions)


def _76():
    print('')


def _89():
    print('Czubem miecza podważasz wieko pudełka. Wewnątrz są 3 sztuki złota.\
    \nMożesz je wziąć.')
    functions.stats_change('Szczęście', constants.s_count, 2)
    functions.stats_change('Złoto', constants.gold_amount, 3)
    print('Rozglądasz się po kątach. Nagle słyszysz jakiś hałas.\
    \nZbierasz szybko swój ekwipunek i wybiegasz zostawiając drzwi otwarte.')
    path_strings = [f'{constants.input_sign}']
    actions = ['paragraphs._120()']
    functions.pth_selector(path_strings, actions)


def _101(entity, state, esc_possible, escape_id, stay_id, to_the_end, p_w_count, e_w_count, win_path):
    print(f'{entities.entity_184.name} prosi o łaskę.')
    path_strings = ['Darujesz mu życie', 'Walczysz aż do końca']
    actions = ['paragraphs._362()', 'paragraphs._234()']
    functions.pth_selector(path_strings, actions)


def _102():
    print("Dochodzisz do skrzyżowania. Korytarze rozchodzą się we wszystkich kierunkach.\
    \nWybierz kierunek:")
    path_strings = ['zachód', 'północ', 'wschód', 'południe']
    actions = ['paragraphs._123()', 'paragraphs._268(door_268.door_state)', 'paragraphs._374()', 'paragraphs._351()']
    functions.pth_selector(path_strings, actions)


def _103():
    print('Wracasz. Mijasz skrzyżowanie. Idziesz na zachód. Po pewnym czasie widzisz\
    \nprzed sobą skrzyżowanie')
    path_strings = [f'{constants.input_sign} ']
    actions = ['paragraphs._345()']
    functions.pth_selector(path_strings, actions)


def _104():
    print('Dajesz motyla, bierzesz złoto i smoczek')
    path_strings = [f'{constants.input_sign} ']
    actions = ['paragraphs._121()']
    functions.pth_selector(path_strings, actions)


def _105():
    print("Próbujesz wyważyć drzwi. Rozpędzasz się i z całej siły uderzasz barkiem.\
    \nDrzwi ani drgnęły.")
    functions.dub_play(f'{constants.assets_audio_pth}/dreszcz_p_105.mp3')
    functions.stats_change('Wytrzymałość', constants.w_count, -1)
    print(f"{constants.def_txt_clr}Czy chcesz ponowić próbę?")
    path_strings = ['tak', 'nie']
    actions = ['paragraphs._56()', 'paragraphs._75()']
    functions.pth_selector(path_strings, actions)


def _106():
    print('Tuż za drzwiami widzisz drewniane, wyszczerbione schody prowadzące w dół.\
    \nW centralnej części pieczary znajduje się kwadratowe zagłębienie, coś jakby basen,\
    \nale pusty. Schody prowadzą właśnie na dno basenu. Posadzka wysypana jest miałkim piaskiem.\
    \nWszędzie piasek, żadnych sprzętów, kamieni, ani istot... Hejże,\
    \na co to za zgięta pała sterczy w rogu basenu? Pewnie jakiś korzeń. Nie możesz odmówić\
    \nsobie tej przyjemności: dajesz mu solidnego kopa. To, co się teraz dzieje,\
    \nprzekracza wyobrażenia. Jeśli przetrwasz i będziesz komuś opowiadał o swojej\
    \nprzygodzie, na pewno nie uwierzy. Basen przypomina teraz garnek, w którymś ktoś\
    \nmiesza gruby makaron. Ty jesteś małym ziarnkiem miotanym we wszystkie strony.\
    \nTo ROBALE, najobrzydliwsze stwory podziemnego świata. Chcą rozetrzeć cię na\
    \nproszek. Wiją swe śliskie cielska. To wyrzucają cię na powierzchnię, to znowu\
    \nprzyciskają cię do dna. Możesz bronić się mieczem. Możesz też\
    \nzastosować inną broń, czyli.. No właśnie: niektórzy mówią, że skuteczną bronią\
    \nprzeciw ROBALOM jest żrący płyn, inni że wszystkożery (wieczne głodne skorupiaki).')
    path_strings = ['Broń się mieczem', 'Masz jedno albo drugie', 'Masz jedno i drugie']
    actions = ['_213()', '_24()', '_292()']
    functions.pth_selector(path_strings, actions)
def _107():
    # initiate combat with entity_107
    functions.combat_init(entities.entity_107, True, entities.entity_107.esc_possible, '', '', '_23()')
def _112():
    value = random.randint(4, 48)
    if value >= 18:
        print('Szczęście ci sprzyja')
        _28()
    else:
        print('Szczęście ci nie sprzyja')
        _291()
def _116a():
    print(f"Odbiegasz w kąt pieczary. Kamienie pryskają spod stóp.\
    \n{entities.entity_116.name} przygląda się uważnie i naciera. Musisz walczyć.")
    functions.dub_play(f'{constants.assets_audio_pth}/dreszcz_p_116a.mp3')
    time.sleep(constants.delay)

    functions.combat_init(entities.entity_116, True, entities.entity_116.esc_possible, '', '', 'paragraphs._116b()')  # initiate combat with entity_116
    # functions.combat_main(entity, state, esc_possible, escape_id, stay_id, to_the_end, p_w_count, e_w_count, win_path)
def _116b():
    functions.dub_play(f'{constants.assets_audio_pth}/dreszcz_p_116b.wav')
    print(f'{constants.def_txt_clr}Możesz rozejrzeć się po pokoju.')
    path_strings = ['Rozejrzyj się', 'Opuść pieczarę']
    actions = ['paragraphs._89()', 'paragraphs._120()']
    functions.pth_selector(path_strings, actions)

def _120():
    print('Idziesz na zachód. Korytarz łagodnie skręca w prawo i teraz prowadzi już na północ.\
    \nWidzisz przed sobą skrzyżowanie.')
    path_strings = [f'{constants.input_sign} ']
    actions = ['paragraphs._64()']
    functions.pth_selector(path_strings, actions)
def _123():
    print(f'Korytarz biegnie na zachód i skręca na południe.\
    \nPrzed sobą widzisz skrzyżowanie.')
    path_strings = [f'{constants.input_sign} ']
    actions = ['paragraphs._39()']
    functions.pth_selector(path_strings, actions)
def _130():
    print('Korytarz ma teraz prawie pięć kroków szerokości.\
    \nIdziesz więc wygodnie. Prostujesz kości.\
    \nPrzeszedłeść zaledwie sto kroków, a tu znowu skrzyżowanie.')
    path_strings = [f'{constants.input_sign} ']
    actions = ['paragraphs._212()']
    functions.pth_selector(path_strings, actions)
def _136():
    print('Smok uprzejmie zaprasza cię na swój ogon, którym trochę - co prawda - buja\
    \nnad jamą, ale zaraz potem lądujesz po drugiej stronie')
    path_strings = [f'{constants.input_sign} ']
    actions = ['paragraphs._186()']
    functions.pth_selector(path_strings, actions)
def _146():
    print('Korytarz biegnie na połódnie i skręca na wschód.\
    \nPrzed sobą widzisz skrzyżowanie.')
    path_strings = [f'{constants.input_sign} ']
    actions = ['paragraphs._64()']
    functions.pth_selector(path_strings, actions)
def _158():
    print('Nie masz dosyć?')
    path_strings = ['Jeszcze raz spróbuj(wymagane przynajmniej 10 sztuk złota) ze Smokiem', 'nie chcesz']
    actions = ["check_for_gold_amount(_64(),_false_path(), 10)", '_269()']
    functions.pth_selector(path_strings, actions)
def _160():
    print('Ostrożnie stawiasz kroki. Nogi ocierają się o liście dorodnej sałaty.\
    \nMijając środek pokoju dostrzegasz padającą z góry strużkę światła.\
    \nNie zdradzasz swego odkrycia. Dochodzisz do stołu')
    path_strings = [f'{constants.input_sign} ']
    actions = ['paragraphs._10()']
    functions.pth_selector(path_strings, actions)
def _170():
    print('Dochodzisz do skrzyżowania. Ma kształt litery T.\
    \nMożesz iść na:')
    path_strings = ['północ', 'wschód', 'południe']
    actions = ['paragraphs._84()', 'paragraphs._319()', 'paragraphs._357()']
    functions.pth_selector(path_strings, actions)
def _175():
    path_strings = [f'{constants.input_sign} ']
    actions = ['paragraphs._373()']
    functions.pth_selector(path_strings, actions)
def _176():
    print('Zbliżasz się do skrzyżowania.\
    \nMożesz pójść na:')
    path_strings = ['północ', 'wschód']
    actions = ['paragraphs._27()', 'paragraphs._230()']
    functions.pth_selector(path_strings, actions)
def _177():
    global s_count
    print('Pod kamieniem schowana była ognista kula. Możesz ją zabrać.\
    \nWychodzisz.')
    functions.stats_change('Szczęście', s_count, 4)
    path_strings = [f'{constants.input_sign} ']
    actions = ['paragraphs._330()']
    functions.pth_selector(path_strings, actions)
def _178():
    print('Coraz trudniej wyciągnąć stopy z błotnistej mazi. Powietrze staje się coraz\
    \nwilgotniejsze. Korytarz stopniowo się rozszerza, aż w końcu wychodzisz na brzeg\
    \npodziemnego jeziora. Brzegi zarośnięte są roślinnością o grubych, szerokich\
    \nliściach. Sklepienie zawieszone jest wysoko. W kilku miejscach przesączają się\
    \nnie cienkie strugi światła. Rozglądasz się uważnie. Czy to ślepy zaułek?\
    \nNie dostrzegasz innego wyjścia niż to, którym przyszedłeś.')
    path_strings = [f'{constants.input_sign} ']
    actions = ['paragraphs._15()']
    functions.pth_selector(path_strings, actions)
def _179():
    path_strings = [f'{constants.input_sign} ']
    actions = ['paragraphs._373()']
    functions.pth_selector(path_strings, actions)
def _180():
    print(f"Ponownie przeszukujesz pokój. W torbie {entities.entity_116.name},\
    \n której nie zdążyłeś przejrzeć, znajdujesz klucz. Jest na nim wygrawerowana liczba 45.\
    \nMożesz go wziąść ze sobą.")
    main_eq.update({"slot5": "klucz z liczbą '45'"})
    keys_eq.update({'slot0': '45'})
    print()
    functions.eq_change("klucz z liczbą '45'")
    path_strings = [f'{constants.input_sign} ']
    actions = ['paragraphs._120()']
    functions.pth_selector(path_strings, actions)
def _181():
    print('Ciskasz w potwora pękiem kluczy, który znalazłeś w jednej z odwiedzonych\
    \nkomnat. Rzut jest celny, ale niegroźny. WILKOŁAK przechwytuje pęk i ucieka.\
    \nRuszasz w pogoń. WILKOŁAK wpada do wąskiej, ale głębokiej rozpadliny znajdującej\
    \nsię w rogu pieczary. Spada na dno i ginie. Przyświecasz sobie latarnią.\
    \nWidzisz w głębi zwaliste cielsko potwora, a obok niego pobłyskują klucze.')
    # Jeśli masz przy sobie linę = 329, jeśli nie masz liny = 32


def _182():
    print('Czy chcesz szukać jakichś sekretnych przejść?')
    path_strings = ['tak', 'nie']
    actions = ['paragraphs._30()', 'paragraphs._259()']
    functions.pth_selector(path_strings, actions)
def _184():
    print('Wycierasz zakrwawiony miecz o skóry leżące pod twoimi nogami.\
    \nNacierasz')
    # initiate combat with entity_184
    functions.combat_init(entities.entity_184, True, entities.entity_184.esc_possible, '_385(', '_226(', '_234()')
def _185():
    print('Wchodzisz do wąskiego korytarzyka. Prowadzi on do dużego pomieszczenia')
    path_strings = [f'{constants.input_sign} ']
    actions = ['paragraphs._252()']
    functions.pth_selector(path_strings, actions)
def _186():
    print('Udało ci się dotrzeć na drugi brzeg. Masz trzy wyjścia:\
    \njedno prowadzi na zachód (A), a dwa na północ,\
    \njedno z nich jest położone bardziej na zachód (B) niż drugie (C).\
    \nKtóre wybierasz?')
    path_strings = ['A', 'B', 'C']
    actions = ['paragraphs._368()', 'paragraphs._117()', 'paragraphs._360()']
    functions.pth_selector(path_strings, actions)
def _200(state):
    functions.dub_play(f'{constants.assets_audio_pth}/dreszcz_p_200.mp3')
    print("Po pewnym czasie dostrzegasz drzwi w południowej ścianie.")
    time.sleep(5)
    if not state:
        print(f'Drzwi są {constants.special_txt_clr}zamknięte{constants.def_txt_clr}.')
        time.sleep(constants.delay)
        functions.dub_play(f'{constants.assets_audio_pth}/dreszcz_door_closed.wav')
        path_strings = [f'{constants.input_sign} ']
        actions = ['paragraphs._301(door_200.door_state)']
        functions.pth_selector(path_strings, actions)
    else:
        print(f'Drzwi są {constants.special_txt_clr}otwarte{constants.def_txt_clr}.')
        time.sleep(constants.delay)
        functions.dub_play(f'{constants.assets_audio_pth}/dreszcz_door_opened.wav')
        path_strings = [f'{constants.input_sign} ']
        actions = ['paragraphs._120()']
        functions.pth_selector(path_strings, actions)
def _212():
    print("Dochodzisz do sporego placyku, którego drogi rozchodzą się w czterech kierunkach.\
    \nKtóry wybierasz?")
    path_strings = ['zachód', 'zachód', 'zachód', 'zachód']
    actions = ['paragraphs._287()', 'paragraphs._38()', 'paragraphs._82()', 'paragraphs._336()']
    functions.pth_selector(path_strings, actions)
def _224():
    print('Po kilkunastu krokach korytarz skręca na wschód. Idziesz dalej.\
    \nW połódniowej ścianie korytarza dostrzegasz drzwi.')
    print(f'Drzwi {constants.special_txt_clr}{objects.door_200.door_ID}{constants.def_txt_clr} są {constants.special_txt_clr}otwarte{constants.def_txt_clr}.')
    path_strings = [f'{constants.input_sign} ']
    actions = ['_180()']
    functions.pth_selector(path_strings, actions)
def _226(entity, state, esc_possible, escape_id, stay_id, to_the_end, p_w_count, e_w_count, win_path):
    print('Walka trwa dalej. Po drugiej rundzie znów możesz Uciec.\
    \nNa pewno chcesz walczyć dalej?')
    path_strings = ['tak', 'nie']
    actions = ['paragraphs._101(entity, state, esc_possible, escape_id, stay_id, to_the_end, p_w_count, e_w_count, win_path)', 'paragraphs._385()']
    functions.pth_selector(path_strings, actions)
def _228():
    print('Korytarz biegnie na północ i skręca w na wschód. Przed sobą widzisz skrzyżowanie.')
    path_strings = [f'{constants.input_sign} ']
    actions = ['paragraphs._102()']
    functions.pth_selector(path_strings, actions)
def _234():
    print(f'{constants.def_txt_clr}Kończysz walkę z DEMONEM. Czy chcesz zajrzeć do kamiennej puszki stojącej na ołtarzyku?')
    path_strings = ['tak', 'nie']
    actions = ['paragraphs._205()', 'paragraphs._199()']
    functions.pth_selector(path_strings, actions)
def _238a():
    print('Napotykasz grupę wędrujących Potworów. Są to: GREMLIN, LICHA, BRONGO, ORKONIK i SAMASKÓRA.\
    \nPo walce z każdym możesz ratować się Ucieczką.')
    # combat_init(entity, state, esc_possible, escape_id, stay_id, win_path_id)
    functions.combat_init(entities.entity_238_1, True, entities.entity_238_1.esc_possible, 'paragraphs._316(', 'paragraphs._xx(', 'paragraphs._238b()')
def _238b():
    path_strings = ['Uciekasz', 'Walczysz dalej']
    actions = ['paragraphs._316()', 'paragraphs._238c()']
    functions.pth_selector(path_strings, actions)
    functions.combat_init(entities.entity_238_2, True, entities.entity_238_2.esc_possible, 'paragraphs._316(', 'paragraphs._xx(', 'paragraphs._238c()')
def _238c():
    path_strings = ['Uciekasz', 'Walczysz dalej']
    actions = ['paragraphs._316()', 'paragraphs._238d()']
    functions.pth_selector(path_strings, actions)
    functions.combat_init(entities.entity_238_3, True, entities.entity_238_3.esc_possible, 'paragraphs._316(', 'paragraphs._xx(', 'paragraphs._238d()')
def _238d():
    path_strings = ['Uciekasz', 'Walczysz dalej']
    actions = ['paragraphs._316()', 'paragraphs._238e()']
    functions.pth_selector(path_strings, actions)
    functions.combat_init(entities.entity_238_4, True, entities.entity_238_4.esc_possible, 'paragraphs._316(', 'paragraphs._xx(', 'paragraphs._238e()')
def _238e():
    path_strings = ['Uciekasz', 'Walczysz dalej']
    actions = ['paragraphs._316()', 'paragraphs._xx()']
    functions.pth_selector(path_strings, actions)
    functions.combat_init(entities.entity_238_5, True, entities.entity_238_5.esc_possible, 'paragraphs._316(', 'paragraphs._xx(', 'paragraphs._316()')
def _242():
    path_strings = [f'{constants.input_sign} ']
    actions = ['action']
    functions.pth_selector(path_strings, actions)
def _264():
    print(f'Trudno przejść przez to zwalisko kamieni.\
    \nNa szczęście korytarz nie wije się we wszystkie strony,\
    \nlecz prowadzi prosto na północ.')
    path_strings = [f'{constants.input_sign} ']
    actions = ['paragraphs._102()']
    functions.pth_selector(path_strings, actions)

def _268(is_open):
    print("Krótki tunel dochodzi do zbutwiałych, starych drzwi.")
    if not is_open:
        print("Jeśli jeszcze za nimi nie byłeś, możesz wejść - patrz 317")
    else:
        print("if: is_open 268 = True")
    print("Jeśli wolisz zawrócić - patrz 102")
    odp = input(f"268 {constants.input_sign} ")
    time.sleep(constants.delay)
    print()
    try:
        odp = float(odp)
    except ValueError:
        time.sleep(constants.delay)
        print()
        _268(objects.door_268.door_state)
    if odp == 317:
        time.sleep(constants.delay)
        print()
        # _317()
    elif odp == 102:
        time.sleep(constants.delay)
        print()
        _102()
    else:
        print(f"{odp} nie spełnia warunków fukcji,")
        time.sleep(constants.delay)
        print()
        _268(objects.door_268.door_state)
def _269():
    global w_count
    print('Wyciągasz z plecaka linę. Jest ognioodporna i zakończona hakiem.\
    \nPodchodzisz do krawędzi. Szerokim zamachem rzucasz hak między skały na przeciwnym brzegu.\
    \nZaczepił się. Przywiązujesz drugi koniec liny. Będziesz "szedł" wisząc na rękach.\
    \nOpuszczasz się. Nagle... trach! Hak puścił. Wdrapujesz się z powrotem.')
    functions.stats_change('Wytrzymałosć', w_count, -2)
    path_strings = ['Zapłać według taryfy(przynajmniej 10 sztuk złota)', 'Podejdź do mostu', 'Spróbuj przeskoczyć przez rozpadlinę(przynajmniej 18W i 9Z)', 'Ponów próbę z liną']
    actions = ['check_for_gold_amount((_35(), pass, 10))', '_110()', '_358()']
    functions.pth_selector(path_strings, actions)
def _284():
    global w_count
    print(f'{constants.def_txt_clr}Korytarz jest coraz węższy, Ze sklepienia zwisają długie, kamienne brody.\
    \nMogą lada chwila urwać się')
    functions.check_for_luck()
    if p_luck:
        print(f"{constants.special_txt_clr}Wytrzymałość: {constants.w_count} {constants.input_sign} {w_count-2}{constants.def_txt_clr}")
        w_count -= 2
        time.sleep(constants.delay)
        print()
    path_strings = [f'{constants.input_sign} ']
    actions = ['paragraphs._50()']
    functions.pth_selector(path_strings, actions)
def _291():
    global w_count
    print(f'{constants.def_txt_clr}Kierujesz się do wyjścia, gdy nagle nie wiadomo skąd\
    \ntrafia cię w brzuch mała, błękitna strzałka.')
    w_count -= 2
    print(f"{constants.special_txt_clr}Wytrzymałość -2 > > {w_count}{constants.def_txt_clr}")
    path_strings = [f'{constants.input_sign} ']
    actions = ['paragraphs._330()']
    functions.pth_selector(path_strings, actions)
def _296():
    print('Korytarz biegnie na zachód i skręca na północ.\
    \nNa zakręcie możesz zjeść Prowiant.')
    functions.eatables()
    print('Idziesz dalej. Przed sobą widzisz skrzyżowanie.')
    path_strings = [f'{constants.input_sign} ']
    actions = ['paragraphs._39()']
    functions.pth_selector(path_strings, actions)
def _301(is_open):
    path_strings = ['Spróbuj otworzyć drzwi', 'Zawróć']
    actions = ['paragraphs._364()', 'paragraphs._120()']
    functions.pth_selector(path_strings, actions)
def _305():
    print('W tej komnacie ukryte jest coś bardzo wartościowego. Żeby to znaleźć musisz wybrać jedną z podanych metod:')
    path_strings = ['zdaj się na los', 'sprawdź czy masz szczęście']
    actions = ['paragraphs._112()', 'paragraphs._381()']
    functions.pth_selector(path_strings, actions)
def _310():
    print('Tylko dziesięć kroków dzieli Cię od zmurszałych, drewnianych drzwi.')
    print('   ///   Sprawdż czy za nimi byłeś: tak-76, nie - 17')
def _316():
    print(f'{constants.def_txt_clr}Idziesz korytarzem na południe')
    path_strings = [f'{constants.input_sign} ']
    actions = ['paragraphs._176()']
    functions.pth_selector(path_strings, actions)
def _330():
    print('Ta komnata ma tylko jedno wyjście: to, którym się tu dostałeś. Wracasz do korytarza.')
    path_strings = [f'{constants.input_sign} ']
    actions = ['_170()']
    functions.pth_selector(path_strings, actions)
def _331(visit_in_turn):
    print('Króciutki tunel prowadzi cię do jakiegoś pomieszczenia.')
    if visit_in_turn == 0:
        objects.room_331.visit_in_turn += 1
        print(f'Jesteś tu pierwszy raz')
        time.sleep(constants.delay)
        path_strings = [f'{constants.input_sign} ']
        actions = ['paragraphs._11()']
        functions.pth_selector(path_strings, actions)
    else:
        print(f'Już tu byłeś')
        path_strings = [f'{constants.input_sign} ']
        actions = ['paragraphs._59()']
        functions.pth_selector(path_strings, actions)
def _332():
    print('Wrota obite są grubą metalową blachą. Ukośnie przebiegają wąskie metalowe\
    \npasy, w miejscach przecięcia nabite żelaznymi guzami. Zapierasz się plecami.\
    \nStopy ślizgają się po grząskim gruncie. Wrota ustępują. Przeraźliwie skrzypią.\
    \nSłyszysz dobiegający z komnaty pospieszny szmer. Wciskasz się do szpary i\
    \nopierając się plecami o skałę z całą mocą odpychasz wrota. Opornie otwierają się\
    \nna całą szerokość. To był szalony wysiłek.')
    constants.w_count += -1
    functions.stats_change('Wytrzymałość', constants.w_count, -1)
    print('Podnosisz latarnię na wysokość\
    \noczu i... serce podchodzi ci do gardła. Schowany za ścianą stoi TROLL. Ciało ma\
    \nwygięte w pałąk. Wysoko za głową oburącz trzyma miecz. Wypina do przodu\
    \nowłosiony brzuch. Szalone oczy nabiegły mu krwią. Szczerzy zaciśnięte zęby.\
    \nJeszcze chwila i ogromny miecz przetnie powietrze. Sięgasz po swój miecz. W\
    \nokamgnieniu TROLL wyprowadza cios. Udaje ci się odskoczyć. To będzie walka na\
    \nśmierć i życie.')
    functions.combat_init(entities.entity_332, True, entities.entity_332.esc_possible, '', '', '_6()')
def _344():
    print(f'Ognista kula jest znakomitą bronią przeciw STRAŻNIKOWI TAJEMNICY.\
    \nJest bardzo skuteczna i szybka. Wraca do twojej ręki po każdym rzucie.\
    \nDaje ci to następujące korzyści podczas walki:\
    \n*możesz dodać 2 do liczby uzyskanej na kostkach przy określaniu siły ataku,\
    \n*każdy atak powoduje nie 2 lecz 3 rany, *gdy STRAŻNIK zrani cię, rzuć kostką:\
    \njeśli uzyskasz liczbę nieparzystą, zadaje ci - jak normalnie - 2 rany;\
    \njeśli wyrzucisz 2 lub 4 otrzymujesz 1 ranę; jeśli masz 6, nie trafia cię w ogóle.')

    functions.combat_init(entities.entity_344, True, entities.entity_344.esc_possible, '', '', "_23()")
def _345():
    print('Idziesz w stronę skrzyżowania. Możesz pójść na:')
    path_strings = ['zachód', 'północ']
    actions = ['_218()', '_267()']
    functions.pth_selector(path_strings, actions)
def _349():
    print(f'Delikatnie wsuwasz stopę w wąską szparę. Biodrami rozpychasz drzwi.\
    \nOdskakują na bok. To jest metoda! Wyczuwasz lekki zapach suszonych ziół.\
    \nPrzy lewej ścianie stoją dwie gładkie kolumienki.\
    \nMiedzy nimi na wysokości oczu rozciągnięta jest granitowa półka.\
    \nStoją tam dwie lampki, a na środku kamienne pudełko.\
    \n\
    \nPosadzka wyłożona jest włochatymi skórami zwierząt i potworów.\
    \nTo chyba podziemna kaplica! Pod ścianą, naprzeciw ołtarzyka widzisz niski, wykuty w skale stół.\
    \nCos tam na nim stoi. Podnosisz wyżej latarnię. Och, królu Almanhagorze, to dwie wazy pełne złota.\
    \nKażda ma taki sam wyszukany kształt. Z jednej strony ozdobiona jest łbem jakiegoś stwora,\
    \nz drugiej - przymocowane są dwa połyskujące skrzydła. Czy chcesz zabrać złoto?')
    path_strings = ['tak', 'nie']
    actions = ['_385(entity, state, esc_possible, escape_id, stay_id, to_the_end, p_w_count, e_w_count)', '_48()']
    functions.pth_selector(path_strings, actions)
def _351():
    print('przeciskasz się przez zawalony kamieniami korytarz.')
    path_strings = [f'{constants.input_sign} ']
    actions = ['_64()']
    functions.pth_selector(path_strings, actions)
def _358():
    print('Zaczepiłeś linę i już "idziesz" po niej. Wtem z wnętrza rozpadliny bucha\
    \njęzor ognia. Jeśli masz przy sobie napój niewidzialności - wypij go.\
    \nOgień nieczyni ci krzywdy. Ale napój przestaje działać zanim docierasz do drugiego brzegu ')
    _xx()
def _364():
    print(f'Popychasz drzwi, uchylają się. Otwiera się ciemna czeluść.\
    \nWchodzisz oświetlając drogę latarnią. Pod stopami czujesz kamyki.\
    \nZ przeciwległego końca pokoju dochodzi ciebie ciche chrapanie.\
    \nNa podłodze śpi {entities.entity_116.name}. Obok niego leży jakieś pudełko.')
    functions.dub_play(f'{constants.assets_audio_pth}/dreszcz_p_364.mp3')
    path_strings = ['Próbujesz zabrać ukradkiem pudełko', 'Decydujesz się podjąć walkę']
    actions = ['paragraphs._29()', 'paragraphs._116a()']
    functions.pth_selector(path_strings, actions)
def _372():
    print("paragraf 372")
def _374():
    print('To nie korytarz, raczej jakiś kanał. Nogi zapadają się w błotnistą maź.\
    \nTunel zmienia kierunek: najpierw skręca na południe, później na wschód, a w końcu na północ.\
    \nPo drodze możesz zjeść Prowiant.')
    functions.eatables()
    path_strings = [f'{constants.input_sign} ']
    actions = ['_178()']
    functions.pth_selector(path_strings, actions)
def _381():
    global p_luck
    functions.check_for_luck()
    if p_luck:
        _28()
    else:
        _291()
def _385(entity, state, esc_possible, escape_id, stay_id, to_the_end, p_w_count, e_w_count):
    print('Możesz wydostać się z komnaty DEMONÓW albo przez wschodnie albo przez zachodnie drzwi.')
    path_strings = ['Wybierz drzwi zachodnie', 'Wybierz drzwi wschodnie']
    actions = ['_345()', '_242()']
    functions.pth_selector(path_strings, actions)