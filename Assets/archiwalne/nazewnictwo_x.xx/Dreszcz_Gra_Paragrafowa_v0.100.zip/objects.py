# / OBJECTS
import pygame
# // entity builder
class Entity:

    def __init__(self, name, entity_z_init, entity_z_count, entity_w_init, entity_w_count, state, esc_possible):
        self.name = name
        self.entity_z_init = entity_z_init
        self.entity_z_count = entity_z_count
        self.entity_w_init = entity_w_init
        self.entity_w_count = entity_w_count
        self.state = state
        self.esc_possible = esc_possible

    # /// attack action
    def attack(self):
        print(f"{self.name} atakuje!")

    # /// die action
    def die(self):
        print(f"{self.name} został zabity!")
        self.state = False

# // door builder
class Door:
    def __init__(self, door_id, door_state, visit_in_turn):
        self.door_ID = door_id
        self.door_state = door_state
        self.visit_in_turn = visit_in_turn

        def open():
            self.door_state = True

        def close():
            self.door_state = False

# // room builder
class Room:
    def __init__(self, room_id, visit_in_turn):
        self.room_id = room_id
        self.visit_in_turn = visit_in_turn


# /// DOORS
door_200 = Door('200', False, 0)
# - - - - - - - - -
door_268 = Door('268', False, 0)
# - - - - - - - - -
door_xxx = Door('xxx', False, 0)


# /// ROOMS
room_331 = Room('331', 0)

