# - - - - - - - - -
# - - - - - - - - -
# - - - - - - - - -
# 'DRESZCZ'
# GRA PARAGRAFOWA
# autor: Jacek Ciesielski 1987
# autor wersji cyfrowej: Filip Pawłowski 2022
# /// wersja: 0.1
# - - - - - - - - -
# - - - - - - - - -
# - - - - - - - - -
import time, pygame
import objects, functions, constants, paragraphs, entities
from colorama import Fore


def main_menu():  # /// START MENU
    functions.clear_terminal()

    odp = ''
    add_after = '?'
    choices = []
    count = 0

    print(f"Witaj {constants.player_name}!\
    \n{constants.def_txt_clr}MAIN MENU{constants.special_txt_clr}", end='')
    time.sleep(constants.delay)

    settings_list = ['_blank_', 'name', 'rpar', 'dif', 'play', 'rules', 'evl', 'exit']
    print(f'\
    \n{constants.def_txt_clr}Wybierz parametr z listy {constants.input_sign}')
    while len(odp) == 0:
        while odp != settings_list:
            print(f"(", end="")
            for i in settings_list:
                choices.append(f"{i}")
                if count < len(settings_list) - 1:
                    print(f"{i} / ", end="")
                    count += 1
                else:
                    print(f"{i})")
            print(f"{Fore.LIGHTWHITE_EX}/*/ Aby dowiedzieć się wiecej dopisz znak: '{add_after}'{constants.special_txt_clr}")
            odp = input(f'{constants.input_sign}{constants.special_txt_clr} ')
            time.sleep(constants.delay)
            if len(odp) != 0:



            # OPCJE Z LISTY



                # /// setting _blank_
                if odp == settings_list[0]:
                    print(f"/// {settings_list[0]}{constants.def_txt_clr}")
                    time.sleep(constants.delay)

                # /?/ explanation
                elif odp == settings_list[0] + add_after:
                    print(f"/?/ {settings_list[0]}{constants.def_txt_clr}")
                    time.sleep(constants.delay)
                    print(f"Parametr '{settings_list[0]}' jest pusty.")



                # /// set player's name
                elif odp == settings_list[1]:
                    print(f"/// {settings_list[1]}{constants.def_txt_clr}")
                    time.sleep(constants.delay)
                    print(f"Wybierz imię bohatera (wpisz 'rnd' aby wylosować imię) {constants.input_sign}")
                    time.sleep(constants.delay)
                    constants.player_name = input(f"{Fore.LIGHTYELLOW_EX}{constants.player_name} {constants.special_txt_clr}{constants.input_sign} ")
                    if constants.player_name == 'rnd':
                        functions.name_randomizer()

                # /?/ explanation
                elif odp == settings_list[1] + add_after:
                    print(f"/?/ {settings_list[1]}{constants.def_txt_clr}")
                    time.sleep(constants.delay)
                    print(f"Parametr '{settings_list[1]}' pozwala wybrać dowolne imię dla bohatera.\
                    \n{Fore.LIGHTWHITE_EX}/*/ wpisz frazę: 'rnd' aby automatycznie wygenrować nowe imię.{constants.special_txt_clr}")
                    print(f"{constants.special_txt_clr}")



                # /// randomize player stats
                elif odp == settings_list[2]:
                    print(f"/// {settings_list[2]}{constants.def_txt_clr}")
                    time.sleep(constants.delay)
                    functions.rpar()
                    print(f'Wylosowano:\
                        \nZręczność:{constants.z_init}\
                        \nWytrzymałość:{constants.w_init}\
                        \nSzczęscie:{constants.s_init}')
                    input(constants.input_sign)

                # /?/ explanation
                elif odp == settings_list[2] + add_after:
                    print(f"/?/ {settings_list[2]}{constants.def_txt_clr}")
                    time.sleep(constants.delay)
                    print(f"Parametr '{settings_list[2]}' resetuje i losuje początkowe statystyki bohatera:\
                    \nZręczność(siła), Wytrzymałość(Życie), Szczęście oraz Imię")



                # /// dif
                elif odp == settings_list[3]:
                    print(f'{constants.def_txt_clr}Wybierz poziom trudności:')
                    path_strings = ['łatwy', 'średni', 'trudny']
                    actions = ['difficulty_selector(d_lvl_e)', 'difficulty_selector(d_lvl_m)', 'difficulty_selector(d_lvl_h)']
                    functions.pth_selector(path_strings, actions)

                # /?/ explanation
                elif odp == settings_list[3] + add_after:
                    print(f"/?/ {settings_list[3]}{constants.def_txt_clr}")
                    print(f"Parametr {settings_list[3]}{constants.def_txt_clr} ustawia poziom trudnośći")



                # /// play
                elif odp == settings_list[4]:
                    pygame.mixer.music.fadeout(3000)
                    functions.loading(3)
                    paragraphs.par_00()

                # /?/ explanation
                elif odp == settings_list[4] + add_after:
                    print(f"/?/ {settings_list[4]}{constants.def_txt_clr}")
                    print(f"Parametr '{settings_list[4]}' zaczyna nową grę")



                # /// rules
                elif odp == settings_list[5]:
                    rules()

                # /?/ explanation
                elif odp == settings_list[5] + add_after:
                    print(f"/?/ {settings_list[5]}{constants.def_txt_clr}")
                    print(f"Parametr '{settings_list[5]}' pokazuje zasady gry.")



                # /// exit settings menu
                elif odp == settings_list[6]:
                    print("Wpisz nazwę funkcji którą chcesz przetestować:")
                    odp = str(input(f"{constants.input_sign}"))
                    eval(odp)

                # /?/ explanation
                elif odp == settings_list[6] + add_after:
                    print(f"/?/ {settings_list[6]}{constants.def_txt_clr}")
                    print(f"Parametr '{settings_list[6]}' służy do bezpośredniego uruchamiania funkcji.\
                    \nIstnieje na czas projektowania\
                    \n")



                # /// exit settings menu
                elif odp == settings_list[7]:
                    pygame.mixer.music.fadeout(1000)
                    time.sleep(1)
                    exit()

                # /?/ explanation
                elif odp == settings_list[7] + add_after:
                    print(f"/?/ {settings_list[7]}{constants.def_txt_clr}")
                    print(f"Parametr '{settings_list[7]}' zamyka program.\
                    \n")



                # /// returns to choice menu
                else:
                    print(f"/!/ '{odp}' nie jest parametrem")
            else:
                print("/!/ proszę wybrać parametr")

                print()
            time.sleep(constants.delay)
            main_menu()

    return constants.player_name


def rules():
    print(f'{constants.def_txt_clr}ZASADY GRY')
    time.sleep(constants.delay)
    print()
    print('I. WYPOSAŻENIE I CECHY')
    time.sleep(constants.delay)
    print()
    print('Jesteś Śmiałkiem.')
    time.sleep(constants.delay)
    print('Twój ekwipunek to:')
    functions.show_equipment_list()
    print('Wędrując po podziemiach będziesz znajdował inne rodzaje broni i przedmioty.\
    \nPamiętaj, że - poza mieczem - każda broń może być wykorzystana tylko raz.\
    \nPodobnie, znajdowane przedmioty są jednorazowego użytku.\
    \nMożesz zabrać ze sobą jedną butelkę eliksiru.')
    input(f'{constants.input_sign} ')
    time.sleep(constants.delay)
    print()
    print(f'Wybierasz spośród eliksirów: {constants.special_txt_clr}ZRĘCZNOŚCI{constants.def_txt_clr},\
    \n{constants.special_txt_clr}WYTRZYMAŁOŚCI{constants.def_txt_clr} i {constants.special_txt_clr}SZCZĘŚCIA{constants.def_txt_clr}.')
    print("Można wypić go w dowolnym momencie, ale tylko dwukrotnie podczas przygody.")
    input(f"{constants.input_sign} ")
    time.sleep(constants.delay)
    print()
    print(f'{constants.def_txt_clr}Twoje cechy to: ZRĘCZNOŚĆ, WYTRZYMAŁOŚĆ i SZCZĘŚCIE.\
    \nPrzed zejściem do podziemi losowane są początkowe poziomy tych cech.\
    \nIch poziom będzie się nieustannie zmieniał podczas wędrówki,\
    \nale nie może przekroczyć poziomu początkowego.')
    input(f"{constants.input_sign} ")
    time.sleep(constants.delay)
    print()
    print('II. WALKA')
    time.sleep(constants.delay)
    print()
    print('Będziesz walczył z potworami. Ich cechy (ZRĘCZNOŚĆ i WYTRZYMAŁOŚĆ) są indywidualne dla każdego wroga.\
    \nSystem walki jest automatycznym procesem. Do końca walki nie ma możliwości interackji,\
    \nchyba że tekst przewiduje możliwość ucieczki.')
    input(f"{constants.input_sign} ")
    time.sleep(constants.delay)
    print()
    print('III. UCIECZKA')
    time.sleep(constants.delay)
    print()
    print('Będąc w niebezpieczeństwie możesz ratować się Ucieczką, o ile tekst to przewiduje.\
    \nJeśli uciekasz, potwór zadaje ci ranę: odejmij 2 od swojej WYTRZYMAŁOŚCI.\
    \nPodczas Ucieczki (przed walką lub w jej trakcie) możesz zastosować SSS w opisany niżej sposób.')
    input(f"{constants.input_sign} ")
    time.sleep(constants.delay)
    print()
    print('IV. SZCZĘŚCIE')
    time.sleep(constants.delay)
    print()
    print('Podczas wędrówki sprawdzasz, czy szczęście ci sprzyja. Robisz to w następujący sposób:\
    \nRzucasz 2K. Jeśli wynik jest równy lub mniejszy od aktualnego poziomu SZCZĘŚCIA, to masz SZCZĘŚCIE.\
    \nJeśli wynik jest większy, nie masz SZCZĘŚCIA.\
    \nTa procedura nazywa się /Sprawdzanie Swojego Szczęścia (SSS).\
    \nPo każdym SSS - niezależnie od wyniku - należy odjąć 1 od aktualnego poziomu SZCZĘŚCIA.\
    \nSSS trzeba zrobić, gdy przewiduje to tekst, a także można zrobić podczas walki.\
    \nPodczas walki SSS robi się w odpowiednim momencie rundy (patrz wyżej), a jego wynik stosuje się tylko do tej rundy.\
    \nOto jakie znaczenie dla przebiegu walki ma SSS:')
    input(f"{constants.input_sign} ")
    time.sleep(constants.delay)
    print()
    print('1. Gdy zadałeś ranę potworowi\
    \n- jeśli masz SZCZĘŚCIE, to odejmujesz dodatkowo 2 od WYTRZYMAŁOŚCI potwora (łącznie -4).\
    \n- jeśli nie masz SZCZĘŚCIA, to odejmujesz łącznie 1.')
    time.sleep(constants.delay)
    print()
    print('2. Gdy potwór zadał ci ranę\
    \n- jeśli masz SZCZĘŚCIE, to odejmujesz łącznie 1 od swojej WYTRZYMAŁOŚCI\
    \n- jeśli nie masz SZCZĘŚCIA, to odejmujesz łącznie 3.')
    input(f'{constants.input_sign} ')
    time.sleep(constants.delay)
    print('\
    \nV. PODWYŻSZANIE POZIOMU CECH')
    time.sleep(constants.delay)
    print('\
    \nPodczas wędrówki, dzięki przygodom i walce, zmienia się poziom twoich cech.')
    input(f'{constants.input_sign} ')
    time.sleep(constants.delay)
    print()
    print('1. ZRĘCZNOŚĆ - niewiele się zmienia\
    \n- zaczarowana broń podwyższa ZRĘCZNOŚĆ\
    \n- eliksir ZRĘCZNOŚCI przywraca poziom początkowy')
    time.sleep(constants.delay)
    print()
    print(f'2. WYTRZYMAŁOŚĆ - nieustannie się zmienia\
    \n- każdy posiłek (masz ich na starcie {constants.eatables_count}) dodaje {constants.eatable_W_load} punkty\
    \n- eliksir WYTRZYMAŁOŚCI przywraca poziom początkowy')
    time.sleep(constants.delay)
    print('\
    \n3. SZCZĘŚCIE\
    \n- udane przygody dodają punkty\
    \n- eliksir SZCZĘŚCIA przywraca poziom początkowy, a nawet podnosi go o 1.\
    \nPoza tym przypadkiem, ZRĘCZNOŚĆ, WYTRZYMAŁOŚĆ i SZCZĘŚCIE nie mogą przekroczyć poziomu początkowego.')
    input(f'{constants.input_sign} ')
    time.sleep(constants.delay)
    print()
    print('VI. PROWIANT')
    time.sleep(constants.delay)
    print()
    print(f'W plecaku masz Prowiant, który wystarcza na {constants.eatables_count} posiłków. Posiłek można zjeść TYLKO wówczas, gdy przewiduje to tekst.\
    \nZa jednym razem można zjeść tylko jeden posiłek. Spożywszy posiłek, dostajesz {constants.eatable_W_load} do swojej WYTRZYMAŁOŚCI.')
    input(f'{constants.input_sign} ')
    time.sleep(constants.delay)
    print()
    print('VII. CEL WYPRAWY')
    time.sleep(constants.delay)
    print()
    print('Twoim celem jest dotarcie do skarbca. Będziesz wędrował przez labirynt korytarzy.\
    \nOdwiedzisz wiele komnat, w których żyją różne istoty. Spotkają cię rozmaite niespodzianki.\
    \nZapewne wpadniesz w jakieś pułapki.\
    \nZnalezienie właściwej drogi i pokonanie potworów nie będzie łatwe.\
    \nZapewne będziesz musiał podjąć kilka wypraw, zanim uda ci się dotrzeć do celu.\
    \nZa każdym razem rysuj mapę podziemi. Bardzo ci pomoże.\
    \n')
    input(f'POWODZENIA!{constants.input_sign} ')
    time.sleep(constants.delay)
    print()
    main_menu()


# entering point
functions.name_randomizer()
functions.rpar()
pygame.mixer.music.load(f'{constants.assets_audio_pth}/menu_background.mp3')
pygame.mixer.music.set_volume(constants.def_bckg_volume)
pygame.mixer.music.play(-1)
main_menu()

#  komenda do kompilacji: pyinstaller --onefile --name Dreszcz_v0.1 --icon icon.ico menu.py functions.py constants.py entities.py objects.py

