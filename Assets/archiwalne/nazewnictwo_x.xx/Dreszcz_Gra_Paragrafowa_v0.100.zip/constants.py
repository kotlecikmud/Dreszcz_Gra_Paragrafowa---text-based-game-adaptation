import pygame
from colorama import Fore

# /// text colors
def_txt_clr = Fore.LIGHTWHITE_EX
entity_txt_clr = Fore.RED
special_txt_clr = Fore.LIGHTMAGENTA_EX
combat_txt_clr = Fore.LIGHTCYAN_EX


# /// constants
delay = 0.3
input_sign = '>>> '
player_name = '<set_name>'
count = 0
z_init = z_count = ''
w_init = w_count = ''
s_init = s_count = ''

# /// selectors
Z_potion = 'zręczności'
W_potion = 'wytrzymałości'
S_potion = 'szczęścia'
count_potion = 2
d_lvl_e = 1
d_lvl_m = 1.2
d_lvl_h = 1.4
e_mult = e_mult_choice = d_lvl_e
p_mult = p_mult_choice = 1
p_hit_val_ = -2*p_mult
e_hit_val_ = -2*e_mult
p_luck = None


# - - - - - - - - -
# SOUND MIXING
# - - - - - - - - -
pygame.mixer.init(frequency = 44100, size = -16, channels = 1, buffer = 2**12)
# - - - - - - - - -
def_action_volume = 0.22
def_bckg_volume = 0.2
assets_audio_pth = 'Assets/Audio'


# /// EKWIPUNEK
# - - - - - - - - -
# - - - - - - - - -
# /// głowy ekwipunek
# - - - - - - - - -
init_eatables_count = eatables_count = 8    # /// początkowa ilość posiłków
eatable_W_load = 4                          # /// ile ładunków wytrzymałości w jednym posiłku
gold_amount = 0                             # /// początkowa ilość sztuk złota
# - - - - - - - - -
main_eq =   {'slot0': 'plecak na Prowiant',
            'slot1': f'prowiant ({eatables_count} porcji)',
            'slot2': 'tarcza',
            'slot3': 'miecz',
            'slot4': f'złoto({gold_amount} sztuk)',
            'slot5': '<slot5>',
            'slot6': '<slot6>',
            'slot7': '<slot7>',
            'slot8': '<slot8>',
            }
# /// ekwipunek na numerowane klucze
# - - - - - - - - -
keys_eq =   {'slot0': '<slot0>',
            'slot1': '<slot1>',
            'slot2': '<slot2>',
            'slot3': '<slot3>',
            'slot4': '<slot4>',
            'slot5': '<slot5>',
            'slot6': '<slot6>',
            'slot7': '<slot7>',
            'slot8': '<slot8>',
            }




# sortowanie

win_path = ''
difficulty_ = ''
init_round_count = 0